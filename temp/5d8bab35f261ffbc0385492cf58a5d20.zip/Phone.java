
/**
 * @date 2012-04-01
 * @author Kasper Koslowski
 */
public class Phone {
    private int type;
    private String number;
    
    public void dial() {
        
    }
}
